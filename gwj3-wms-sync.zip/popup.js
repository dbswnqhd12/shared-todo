const WMS_ORIGIN = 'https://inventory.coupang.com';
const SEARCH_PATH = '/async/inventory/search';
const FIELDS = ['zone', 'locationBarcode', 'skuId'];

const $ = (id) => document.getElementById(id);
const setStatus = (msg) => { $('status').textContent = msg; };

function buildParams() {
  const p = {
    searched: 'true', locationType: '', zone: '', fromLocation: '', toLocation: '',
    locationBarcode: '', skuId: '', externalSkuId: '', skuBarcode: '', lpnId: '',
    inventoryId: '', saleableChangeType: '',
    availableInventory: $('availableInventory').checked ? 'true' : 'false',
  };
  for (const f of FIELDS) p[f] = $(f).value.trim();
  return p;
}

async function findWmsTab() {
  const tabs = await chrome.tabs.query({ url: WMS_ORIGIN + '/*' });
  if (!tabs.length) throw new Error('WMS(inventory.coupang.com) 탭을 먼저 열고 로그인해 주세요.');
  return tabs[0];
}

// Runs inside the WMS tab so the request carries the logged-in session.
async function fetchInPage(path, params, mode) {
  const PAGE_SIZE = 100;
  const MAX_PAGES = 300;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // Find the largest array of objects anywhere in the JSON.
  function findRows(obj) {
    let best = null;
    (function walk(v, depth) {
      if (depth > 6 || v === null || typeof v !== 'object') return;
      if (Array.isArray(v)) {
        if (v.length && typeof v[0] === 'object' && (!best || v.length > best.length)) best = v;
        v.forEach((x) => walk(x, depth + 1));
      } else {
        Object.values(v).forEach((x) => walk(x, depth + 1));
      }
    })(obj, 0);
    return best || [];
  }

  function tableRows(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const table = doc.querySelector('table');
    if (!table) return null;
    const heads = [...table.querySelectorAll('thead th, tr:first-child th')].map((th) => th.textContent.trim());
    return [...table.querySelectorAll('tbody tr')].map((tr) => {
      const cells = [...tr.querySelectorAll('td')].map((td) => td.textContent.trim());
      const row = {};
      cells.forEach((c, i) => { row[heads[i] || 'col' + (i + 1)] = c; });
      return row;
    });
  }

  // Replace values with their type so the structure can be shared safely.
  function mask(v, depth = 0) {
    if (v === null) return null;
    if (Array.isArray(v)) return v.length ? [mask(v[0], depth + 1), `...(${v.length}개)`] : [];
    if (typeof v === 'object') {
      if (depth > 6) return '{...}';
      const o = {};
      for (const [k, x] of Object.entries(v)) o[k] = mask(x, depth + 1);
      return o;
    }
    return typeof v;
  }

  async function getPage(page, size) {
    const qs = new URLSearchParams({ ...params, page: String(page), pageSize: String(size) });
    const res = await fetch(path + '?' + qs.toString(), {
      credentials: 'include',
      headers: { 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json, text/html, */*' },
    });
    if (res.status === 401 || res.status === 403) throw new Error('로그인이 풀린 것 같아요. WMS에 다시 로그인해 주세요.');
    if (!res.ok) throw new Error('WMS 응답 오류: HTTP ' + res.status);
    const text = await res.text();
    try { return { json: JSON.parse(text) }; } catch { return { html: text }; }
  }

  try {
    if (mode === 'structure') {
      const r = await getPage(0, 2);
      if (r.json) return { ok: true, structure: JSON.stringify(mask(r.json), null, 2) };
      return { ok: true, structure: 'HTML 응답입니다. 앞부분:\n' + r.html.replace(/\s+/g, ' ').slice(0, 1500) };
    }

    const all = [];
    let total = null;
    for (let page = 0; page < MAX_PAGES; page++) {
      const r = await getPage(page, PAGE_SIZE);
      let rows;
      if (r.json) {
        rows = findRows(r.json);
        const j = r.json;
        total = total ?? j.totalPages ?? j.data?.totalPages ?? j.page?.totalPages ?? null;
      } else {
        rows = tableRows(r.html);
        if (rows === null) throw new Error('응답에서 표를 찾지 못했어요. "응답 구조 복사"로 보내주세요.');
      }
      all.push(...rows);
      if (!rows.length || (total !== null && page + 1 >= total) || (total === null && rows.length < PAGE_SIZE)) break;
      await sleep(300);
    }
    return { ok: true, rows: all };
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
}

function flatten(obj, prefix = '', out = {}) {
  for (const [k, v] of Object.entries(obj)) {
    const key = prefix ? prefix + '.' + k : k;
    if (v && typeof v === 'object' && !Array.isArray(v)) flatten(v, key, out);
    else out[key] = Array.isArray(v) ? JSON.stringify(v) : v;
  }
  return out;
}

function toCsv(rows) {
  const flat = rows.map((r) => flatten(r));
  const cols = [...new Set(flat.flatMap((r) => Object.keys(r)))];
  const esc = (v) => {
    const s = v === undefined || v === null ? '' : String(v);
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return [cols.join(','), ...flat.map((r) => cols.map((c) => esc(r[c])).join(','))].join('\r\n');
}

async function run(mode) {
  const btns = [$('sync'), $('structure')];
  btns.forEach((b) => (b.disabled = true));
  setStatus(mode === 'structure' ? '응답 구조를 읽는 중...' : '데이터 받아오는 중...');
  try {
    const params = buildParams();
    chrome.storage.local.set({ filters: params });
    const tab = await findWmsTab();
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: fetchInPage,
      args: [SEARCH_PATH, params, mode],
    });
    if (!result.ok) throw new Error(result.error);

    if (mode === 'structure') {
      await navigator.clipboard.writeText(result.structure);
      setStatus('복사됐어요. Claude 대화창에 붙여넣어 주세요.\n(실제 값은 지우고 형식만 담았습니다)');
      return;
    }

    if (!result.rows.length) { setStatus('조건에 맞는 데이터가 없어요.'); return; }
    const csv = '﻿' + toCsv(result.rows);
    const stamp = new Date().toLocaleString('sv-SE').replace(/[: ]/g, '-').slice(0, 16);
    const url = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    await chrome.downloads.download({ url, filename: `wms-inventory-${stamp}.csv` });
    const now = new Date().toLocaleString('ko-KR');
    chrome.storage.local.set({ lastSync: now, lastCount: result.rows.length });
    setStatus(`완료: ${result.rows.length}건을 받았어요.`);
    showLast(now, result.rows.length);
  } catch (e) {
    setStatus('⚠ ' + (e.message || e));
  } finally {
    btns.forEach((b) => (b.disabled = false));
  }
}

function showLast(time, count) {
  if (time) $('last').textContent = `마지막 동기화: ${time} (${count}건)`;
}

chrome.storage.local.get(['filters', 'lastSync', 'lastCount'], ({ filters, lastSync, lastCount }) => {
  if (filters) {
    for (const f of FIELDS) $(f).value = filters[f] || '';
    $('availableInventory').checked = filters.availableInventory !== 'false';
  }
  showLast(lastSync, lastCount);
});

$('sync').addEventListener('click', () => run('rows'));
$('structure').addEventListener('click', () => run('structure'));
